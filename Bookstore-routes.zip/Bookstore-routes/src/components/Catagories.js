const Catagories = () => (
  <button type="button" className="check-btn">Check status</button>
);

export default Catagories;
